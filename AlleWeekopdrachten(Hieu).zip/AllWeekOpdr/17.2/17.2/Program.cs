﻿using System;
using System.Collections.Generic;

class Program
{
    static void Main()
    {
        // Gebruik Dictionary voor de encyclopedie
        Dictionary<string, string> encyclopedie = new Dictionary<string, string>
        {
            { "Abstractie", "Het proces van het weglaten van minder essentiële informatie zodat alleen de meest essentiële kenmerken overblijven." },
            { "Algoritme", "Een stapsgewijze procedure voor het uitvoeren van een taak of het berekenen van een waarde." },
            { "Array", "Een geordende verzameling elementen, typisch van hetzelfde type." },
            { "Class", "Een blauwdruk voor een object in objectgeoriënteerd programmeren." },
            { "Encapsulatie", "Een objectgeoriënteerd programmeerprincipe waarbij de interne staat van een object verborgen wordt." },
            { "Erfenis", "Het vermogen van een nieuwe klasse om de eigenschappen en methoden van een andere klasse over te nemen." },
            { "Framework", "Een set van codebibliotheken en tools die helpen bij het ontwikkelen van software." },
            { "Interface", "Een contract in OOP dat definieert welke methodes een klasse moet implementeren." },
            { "Iteratie", "Het herhaaldelijk uitvoeren van een set instructies totdat een bepaalde voorwaarde is voldaan." },
            { "Namespace", "Een container die wordt gebruikt om sets van andere benoemde entiteiten onder een unieke naam te groeperen." },
            { "Polymorfisme", "Het vermogen van verschillende klassen om te reageren op dezelfde boodschap op verschillende manieren." },
            { "Recursie", "Een techniek in programmeren waar een functie zichzelf oproept." },
            { "Serialize", "Het proces van omzetten van een object naar een formaat dat kan worden opgeslagen of overgedragen." },
            { "Syntax", "De set regels die definiëren hoe instructies in een programmeertaal zijn opgebouwd." },
            { "Variable", "Een opslaglocatie met een geassocieerde naam en een waarde die kan veranderen tijdens de uitvoering van een programma." }
        };

        while (true)
        {
            Console.Clear();
            Console.WriteLine("Welkom bij de programmeerencyclopedie!");
            Console.WriteLine("Voer een begrip in (of type 'exit' om te stoppen):");

            string input = Console.ReadLine().Trim();

            if (input.ToLower() == "exit")
            {
                break;
            }

            if (encyclopedie.TryGetValue(input, out string uitleg))
            {
                Console.WriteLine($"\nUitleg van '{input}': {uitleg}");
            }
            else
            {
                Console.WriteLine($"\nHet begrip '{input}' is niet gevonden in de encyclopedie.");
            }

            Console.WriteLine("\nDruk op een toets om door te gaan...");
            Console.ReadKey();
        }
    }
}
