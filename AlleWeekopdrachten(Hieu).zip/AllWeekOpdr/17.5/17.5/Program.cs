﻿using System;
using System.Collections.Generic;

class Evenement
{
    // Dictionary om de kortingscodes en hun status (gebruikt/niet gebruikt) op te slaan
    static Dictionary<string, bool> kortingscodes = new Dictionary<string, bool>
    {
        {"P5CQV", false},
        {"MVFHC", false},
        {"P1WVX", false},
        {"H15QA", false},
        {"CKWX2", false},
        {"B45SO", false},
        {"1VRFH", false},
        {"KSVQO", false},
        {"WH83H", false},
        {"AOZMT", false},
        {"DSTCH", false},
        {"VQ1H6", false},
        {"C03GB", false},
        {"1N9YM", false},
        {"8W7F8", false}
    };

    static void Main()
    {
        Console.WriteLine("Voer een kortingscode in:");

        while (true)
        {
            string ingevoerdeCode = Console.ReadLine().ToUpper();  // Lees de ingevoerde code en zet deze om naar hoofdletters

            // Controleer of de gebruiker "exit" typt om het programma te verlaten
            if (ingevoerdeCode == "EXIT")
            {
                break;
            }

            // Controleer of de kortingscode geldig is
            if (kortingscodes.ContainsKey(ingevoerdeCode))
            {
                // Controleer of de kortingscode al gebruikt is
                if (kortingscodes[ingevoerdeCode])
                {
                    Console.WriteLine($"Kortingscode {ingevoerdeCode} is al gebruikt.");
                }
                else
                {
                    Console.WriteLine($"Kortingscode {ingevoerdeCode} is geldig. De code is nu gemarkeerd als gebruikt.");
                    kortingscodes[ingevoerdeCode] = true;  // Markeer de code als gebruikt
                }
            }
            else
            {
                Console.WriteLine($"Kortingscode {ingevoerdeCode} is ongeldig.");
            }

            Console.WriteLine("\nVoer een nieuwe kortingscode in (of type 'exit' om af te sluiten):");
        }
    }
}
