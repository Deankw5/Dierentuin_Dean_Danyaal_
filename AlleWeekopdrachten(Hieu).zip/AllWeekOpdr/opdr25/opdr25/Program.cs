﻿using System;
using System.Collections.Generic;

// Strategy Interface
public interface IPrintStrategy
{
    void Print(string text);
}
// Code Smell: Geen validatie voor negatieve of 0 waarden hier. Dit kan later fouten veroorzaken.
// Concrete Strategies
public class DefaultPrintStrategy : IPrintStrategy
{
    public void Print(string text)
    {
        Console.WriteLine(text);
    }
}


public class RepeatPrintStrategy : IPrintStrategy
{
    private int _count;

    public RepeatPrintStrategy(int count)
    {
        _count = count;
    }

    public void Print(string text)
    {
        for (int i = 0; i < _count; i++)
        {
            Console.WriteLine($"{i + 1}: {text}");
        }
    }
}

public class StarPrintStrategy : IPrintStrategy
{
    public void Print(string text)
    {
        Console.WriteLine($"****{text}****");
    }
}

public class ReversePrintStrategy : IPrintStrategy
{
    public void Print(string text)
    {
        char[] array = text.ToCharArray();
        Array.Reverse(array);
        Console.WriteLine(new string(array));
    }
}

// Context
public class Printer
{
    private IPrintStrategy _strategy;

    public Printer(IPrintStrategy strategy)
    {
        _strategy = strategy;
    }

    public void SetStrategy(IPrintStrategy strategy)
    {
        _strategy = strategy;
    }

    public void PrintText(string text)
    {
        _strategy.Print(text);
    }
}

public class Program
{
    public static void Main(string[] args)
    {
        Console.WriteLine("Voer tekst in om uit te printen");
        string text = Console.ReadLine();

        Console.WriteLine("Welk print strategy wil je hanteren?\n(1) 1 keer\n(2) herhaald\n(3) met sterren\n(4) achterstevoren");
        int choice = Convert.ToInt32(Console.ReadLine());

        Printer printer;

        // Kies de printstrategie op basis van de keuze
        switch (choice)
        {
            case 2:
                // Vraag hoeveel keer de tekst herhaald moet worden
                Console.WriteLine("Hoe vaak wil je dat de tekst herhaald wordt?");
                int count = Convert.ToInt32(Console.ReadLine());
                printer = new Printer(new RepeatPrintStrategy(count));
                break;
            case 3:
                // Stel in dat de tekst met sterren wordt afgedrukt
                printer = new Printer(new StarPrintStrategy());
                break;
            case 4:
                // Stel in dat de tekst achterstevoren wordt afgedrukt
                printer = new Printer(new ReversePrintStrategy());
                break;
            default:
                // Standaard print de tekst 1 keer
                printer = new Printer(new DefaultPrintStrategy());
                break;
        }

        // Gebruik de geselecteerde strategie om de tekst af te drukken
        printer.PrintText(text);
    }
}
