﻿using System;

class Program
{
    static void Main()
    {
        int getal;
        bool isGeldig;

        do
        {
            // Code Smell: Lange Methode (Long Method)
            // Probleem: De logica voor het verkrijgen van invoer en de validatie zit in één grote methode.
            // Mogelijke Nadeel: Moeilijk te onderhouden en uit te breiden.
            // Oplossing: Verdeel de logica in kleinere methoden.
            // Refactoring Techniek: Extract Method.

            // Vraag de gebruiker om een getal in te voeren
            Console.Write("Voer een getal in tussen 1 en 10: ");
            string invoer = Console.ReadLine();

            // Probeer de invoer om te zetten naar een integer
            isGeldig = int.TryParse(invoer, out getal);

            // Controleer of het getal binnen het bereik valt en of de conversie geslaagd is
            if (isGeldig && getal >= 1 && getal <= 10)
            {
                // Als het getal geldig is, bevestig de invoer en breek de loop
                Console.WriteLine($"Je hebt een geldig getal ingevoerd: {getal}");
            }
            else
            {
                // Code Smell: Repetitieve Code
                // Probleem: De foutmelding en validatie komen herhaaldelijk voor.
                // Mogelijke Nadeel: Moeilijker te onderhouden bij veranderingen.
                // Oplossing: Zet de foutverwerking in een aparte methode.
                // Refactoring Techniek: Extract Method.

                // Als het getal niet geldig is, geef een foutmelding en vraag opnieuw om invoer
                Console.WriteLine("Het getal moet een geheel getal tussen 1 en 10 zijn. Probeer het opnieuw.");
                isGeldig = false; // Zorg ervoor dat de loop blijft draaien
            }

        } while (!isGeldig); // Herhaal totdat een geldig getal is ingevoerd
    }
}