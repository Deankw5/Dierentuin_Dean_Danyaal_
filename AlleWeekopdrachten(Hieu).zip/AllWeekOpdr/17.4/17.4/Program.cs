﻿using System;
using System.Collections.Generic;

class Snackbar
{
    static void Main()
    {
        // Gebruik een List<string> voor de bestellingenlijst
        List<string> bestellingen = new List<string>
        {
            "3x Frietje, 2x Frikandel, 1x Cola",
            "1x Frietje Speciaal, 2x Kroket, 1x Water, 3x Kaassoufflé",
            "2x Frietje, 1x Frikandel Speciaal, 2x Bier",
            "4x Kaassoufflé, 2x Cola",
            "2x Frietje Oorlog, 1x Frikandel, 1x Milkshake",
            "3x Kroket, 2x Frikandel, 1x Cola, 1x Frietje",
            "1x Frietje, 3x Bitterballen, 2x Limoen",
            "2x Frietje Speciaal, 1x Frikandel, 2x Kroket",
            "4x Frikandel, 1x Frietje Groot",
            "3x Frietje, 2x Kaassoufflé, 1x Milkshake Vanille",
            "2x Kroket, 1x Frikandel Speciaal, 2x Water",
            "1x Frietje Oorlog, 2x Cola, 3x Frikandel",
            "2x Frietje, 1x Bier, 3x Bitterballen",
            "1x Frietje Groot, 2x Frikandel Speciaal, 1x Cola",
            "3x Kroket, 2x Frietje Speciaal, 1x Water"
        };

        // Toon alle bestellingen
        Console.WriteLine("Bestellingen lijst:");
        ToonBestellingen(bestellingen);

        // Voeg een nieuwe bestelling toe
        string nieuweBestelling = "2x Frietje, 1x Milkshake Chocolade";
        VoegBestellingToe(bestellingen, nieuweBestelling);

        // Verwijder een bestelling (bijv. de bestelling met index 2)
        VerwijderBestelling(bestellingen, 2);

        // Update een bestelling (bijv. bestelling met index 1)
        string aangepasteBestelling = "1x Frietje Speciaal, 2x Kroket, 1x Water, 4x Kaassoufflé";
        UpdateBestelling(bestellingen, 1, aangepasteBestelling);

        // Toon de bijgewerkte lijst
        Console.WriteLine("\nBijgewerkte bestellingen lijst:");
        ToonBestellingen(bestellingen);
    }

    // Methode om alle bestellingen te tonen
    static void ToonBestellingen(List<string> bestellingen)
    {
        // Code Smell: Feature Envy
        // Probleem: De methode behandelt de index en string als aparte elementen.
        // Mogelijk nadeel: Moeilijk uit te breiden naar meer complexe bestelstructuren.
        // Oplossing: Introduceer een klasse om een bestelling te representeren.
        // Refactoring techniek: Replace Data Value with Object.
        for (int i = 0; i < bestellingen.Count; i++)
        {
            Console.WriteLine($"{i + 1}. {bestellingen[i]}");
        }
    }

    // Methode om een nieuwe bestelling toe te voegen
    static void VoegBestellingToe(List<string> bestellingen, string bestelling)
    {
        // Code Smell: Primitive Obsession
        // Probleem: Gebruik van strings om bestellingen te representeren beperkt flexibiliteit.
        // Mogelijk nadeel: Geen ondersteuning voor validatie of extra eigenschappen.
        // Oplossing: Gebruik een klasse voor bestellingen.
        // Refactoring techniek: Replace Primitive with Object.
        bestellingen.Add(bestelling);
        Console.WriteLine($"\nNieuwe bestelling toegevoegd: {bestelling}");
    }

    // Methode om een bestelling te verwijderen op basis van index
    static void VerwijderBestelling(List<string> bestellingen, int index)
    {
        // Code Smell: Duplicated Code
        // Probleem: Indexvalidatie wordt herhaald in meerdere methoden.
        // Mogelijk nadeel: Moeilijk onderhoudbare code bij wijzigingen.
        // Oplossing: Verplaats validatie naar een aparte methode.
        // Refactoring techniek: Extract Method.
        if (index >= 0 && index < bestellingen.Count)
        {
            Console.WriteLine($"\nBestelling verwijderd: {bestellingen[index]}");
            bestellingen.RemoveAt(index);
        }
        else
        {
            Console.WriteLine("Ongeldige index. Kan bestelling niet verwijderen.");
        }
    }

    // Methode om een bestelling bij te werken op basis van index
    static void UpdateBestelling(List<string> bestellingen, int index, string nieuweBestelling)
    {
        // Code Smell: Long Parameter List
        // Probleem: De methode vereist een index en een string, wat inefficiënt kan zijn.
        // Mogelijk nadeel: Toevoegen van nieuwe parameters leidt tot complexe methodesignaturen.
        // Oplossing: Gebruik een Request-object of klasse.
        // Refactoring techniek: Introduce Parameter Object.
        if (index >= 0 && index < bestellingen.Count)
        {
            Console.WriteLine($"\nBestelling bijgewerkt: {bestellingen[index]} => {nieuweBestelling}");
            bestellingen[index] = nieuweBestelling;
        }
        else
        {
            Console.WriteLine("Ongeldige index. Kan bestelling niet bijwerken.");
        }
    }
}
