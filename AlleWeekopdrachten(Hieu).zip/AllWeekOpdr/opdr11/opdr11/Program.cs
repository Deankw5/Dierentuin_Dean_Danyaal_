﻿using System;
using System.Collections.Generic;

namespace ConsoleVoorbeeld
{
    class Program
    {
        static void Main(string[] args)
        {
            while (true)
            {
                Console.Clear();
                Console.WriteLine("Hoofdmenu:");
                Console.WriteLine("1. Cijfer Beoordeling (opdracht 1)");
                Console.WriteLine("2. FizzBuzz (opdracht 2)");
                Console.WriteLine("3. Hoger Lager Spel (opdracht 3)");
                Console.WriteLine("4. Getal Validatie (opdracht 4)");
                Console.WriteLine("5. FizzBuzz Tot 100 (opdracht 5)");
                Console.WriteLine("6. Namen Korter Dan 5 Letters (opdracht 6)");
                Console.WriteLine("7. Priemgetallen (opdracht 7)");
                Console.WriteLine("8. Getallen 1 tot 50, Behalve Deelbaar Door 3 (opdracht 8)");
                Console.WriteLine("9. Score naar Beoordeling (opdracht 9)");
                Console.WriteLine("10. Rekensom Quiz (opdracht 10)");
                Console.WriteLine("11. Exit");

                Console.Write("Kies een optie (1-11): ");
                string keuze = Console.ReadLine();

                switch (keuze)
                {
                    case "1":
                        Opdracht1();
                        break;
                    case "2":
                        Opdracht2();
                        break;
                    case "3":
                        Opdracht3();
                        break;
                    case "4":
                        Opdracht4();
                        break;
                    case "5":
                        Opdracht5();
                        break;
                    case "6":
                        Opdracht6();
                        break;
                    case "7":
                        Opdracht7();
                        break;
                    case "8":
                        Opdracht8();
                        break;
                    case "9":
                        Opdracht9();
                        break;
                    case "10":
                        Opdracht10();
                        break;
                    case "11":
                        Environment.Exit(0);
                        break;
                    default:
                        Console.WriteLine("Ongeldige keuze, probeer het opnieuw.");
                        break;
                }
            }
        }

        static void Opdracht1()
        {
            Console.WriteLine("Vul cijfer in 1 tot 10:");
            string input = Console.ReadLine();

            switch (int.TryParse(input, out int number) ? number : -1)
            {
                case 1: Console.WriteLine("Zeer slecht"); break;
                case 2: Console.WriteLine("Slecht"); break;
                case 3: Console.WriteLine("Matig"); break;
                case 4: Console.WriteLine("Onvoldoende"); break;
                case 5: Console.WriteLine("Bijna voldoende"); break;
                case 6: Console.WriteLine("Voldoende"); break;
                case 7: Console.WriteLine("Ruim voldoende"); break;
                case 8: Console.WriteLine("Goed"); break;
                case 9: Console.WriteLine("Zeer goed"); break;
                case 10: Console.WriteLine("Uitmuntend"); break;
                default: Console.WriteLine("Ongeldige invoer. Voer een cijfer tussen 1 en 10 in."); break;
            }
            WachtOpInput();
        }

        static void Opdracht2()
        {
            Console.WriteLine("Vul een cijfer in tussen 1,0 en 10,0:");
            string input = Console.ReadLine();
            if (double.TryParse(input, out double number))
            {
                if (number >= 1.0 && number <= 10.0)
                {
                    if (number >= 9.0) Console.WriteLine("Uitmuntend");
                    else if (number >= 8.0) Console.WriteLine("Zeer goed");
                    else if (number >= 7.0) Console.WriteLine("Goed");
                    else if (number >= 6.0) Console.WriteLine("Voldoende");
                    else if (number >= 5.0) Console.WriteLine("Bijna voldoende");
                    else if (number >= 4.0) Console.WriteLine("Onvoldoende");
                    else if (number >= 3.0) Console.WriteLine("Matig");
                    else if (number >= 2.0) Console.WriteLine("Slecht");
                    else Console.WriteLine("Zeer slecht");
                }
                else
                {
                    Console.WriteLine("Ongeldige invoer. Voer een getal tussen 1,0 en 10,0 in.");
                }
            }
            else
            {
                Console.WriteLine("Dit is geen cijfer");
            }
            WachtOpInput();
        }

        static void Opdracht3()
        {
            int geheimNummer = Random.Shared.Next(1, 100);
            int poging;
            bool geraden = false;

            Console.WriteLine("Welkom bij het Hoger-Lager Spel!");
            Console.WriteLine("Raad het geheime getal tussen 1 en 99.");

            while (!geraden)
            {
                Console.Write("Voer je gok in: ");
                string input = Console.ReadLine();

                if (int.TryParse(input, out poging))
                {
                    if (poging >= 1 && poging <= 99)
                    {
                        if (poging < geheimNummer) Console.WriteLine("Hoger!");
                        else if (poging > geheimNummer) Console.WriteLine("Lager!");
                        else
                        {
                            Console.WriteLine($"Gefeliciteerd! Je hebt het juiste getal {geheimNummer} geraden!");
                            geraden = true;
                        }
                    }
                    else
                    {
                        Console.WriteLine("Ongeldige invoer. Voer een getal tussen 1 en 99 in.");
                    }
                }
                else
                {
                    Console.WriteLine("Ongeldige invoer. Voer een geldig getal in.");
                }
            }

            Console.WriteLine("Bedankt voor het spelen!");
            WachtOpInput();
        }

        static void Opdracht4()
        {
            int getal;
            bool isGeldig;

            do
            {
                Console.Write("Voer een getal in tussen 1 en 10: ");
                string invoer = Console.ReadLine();

                isGeldig = int.TryParse(invoer, out getal);

                if (isGeldig && getal >= 1 && getal <= 10)
                {
                    Console.WriteLine($"Je hebt een geldig getal ingevoerd: {getal}");
                }
                else
                {
                    Console.WriteLine("Het getal moet een geheel getal tussen 1 en 10 zijn. Probeer het opnieuw.");
                    isGeldig = false;
                }

            } while (!isGeldig);
            WachtOpInput();
        }

        static void Opdracht5()
        {
            for (int i = 1; i <= 100; i++)
            {
                if (i % 3 == 0 && i % 5 == 0) Console.WriteLine("FizzBuzz");
                else if (i % 3 == 0) Console.WriteLine("Fizz");
                else if (i % 5 == 0) Console.WriteLine("Buzz");
                else Console.WriteLine(i);
            }
            WachtOpInput();
        }

        static void Opdracht6()
        {
            List<string> namen = new List<string> { "Anna", "Bob", "Charlie", "Dave", "Eva", "Frank", "Grace", "Harry", "Ivy", "Jack" };

            foreach (string naam in namen)
            {
                if (naam.Length < 5) Console.WriteLine(naam);
            }
            WachtOpInput();
        }

        static void Opdracht7()
        {
            int count = 0;
            int number = 2;

            while (true)
            {
                if (IsPrime(number))
                {
                    Console.WriteLine(number);
                    count++;
                    if (count >= 10) break;
                }
                number++;
            }
            WachtOpInput();
        }

        static void Opdracht8()
        {
            for (int i = 1; i <= 50; i++)
            {
                if (i % 3 == 0) continue;
                Console.WriteLine(i);
            }
            WachtOpInput();
        }

        static void Opdracht9()
        {
            Console.Write("Voer een score in tussen 0 en 100: ");
            if (int.TryParse(Console.ReadLine(), out int score))
            {
                if (score < 0 || score > 100)
                {
                    Console.WriteLine("De score moet tussen 0 en 100 liggen.");
                }
                else
                {
                    string beoordeling = score < 50 ? "Slecht" :
                                         score < 60 ? "Matig" :
                                         score < 75 ? "Voldoende" :
                                         score < 90 ? "Goed" :
                                                      "Uitstekend";

                    Console.WriteLine("Beoordeling: " + beoordeling);
                }
            }
            else
            {
                Console.WriteLine("Ongeldige invoer. Voer een geldig cijfer in.");
            }
            WachtOpInput();
        }

        static void Opdracht10()
        {
            var vragen = new List<string>
            {
                "Vraag 1: Wat is 1 + 1?\n(a) 1\n(b) 2\n(c) 3",
                "Vraag 2: Wat is 5 - 3?\n(a) 1\n(b) 2\n(c) 3",
                "Vraag 3: Wat is 7 * 2?\n(a) 12\n(b) 14\n(c) 16",
                "Vraag 4: Wat is 9 / 3?\n(a) 2\n(b) 3\n(c) 4",
                "Vraag 5: Wat is 8 + 4?\n(a) 10\n(b) 12\n(c) 14"
            };

            var antwoorden = new List<string> { "b", "c", "b", "b", "b" };

            var gebruikersAntwoorden = new List<string>();
            int score = 0;

            for (int i = 0; i < vragen.Count; i++)
            {
                Console.WriteLine(vragen[i]);
                Console.Write("Voer je antwoord in (a, b, c): ");
                string antwoord = Console.ReadLine().ToLower();

                if (antwoord == antwoorden[i])
                {
                    score++;
                    gebruikersAntwoorden.Add($"Vraag {i + 1}: Goed");
                }
                else
                {
                    gebruikersAntwoorden.Add($"Vraag {i + 1}: Fout");
                }
            }

            Console.WriteLine("\nOverzicht van je antwoorden:");
            foreach (var resultaat in gebruikersAntwoorden)
            {
                Console.WriteLine(resultaat);
            }

            Console.WriteLine($"\nJe totale score is: {score} van de {vragen.Count} vragen.");
            WachtOpInput();
        }

        static void WachtOpInput()
        {
            Console.WriteLine("\nDruk op een toets om naar het hoofdmenu te gaan.");
            Console.ReadKey();
        }

        static bool IsPrime(int number)
        {
            if (number <= 1) return false;
            if (number <= 3) return true;
            if (number % 2 == 0 || number % 3 == 0) return false;

            for (int i = 5; i * i <= number; i += 6)
            {
                if (number % i == 0 || number % (i + 2) == 0) return false;
            }

            return true;
        }
    }
}