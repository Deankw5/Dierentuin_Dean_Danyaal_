﻿using System;
using System.Collections.Generic;

class Program
{
    static void Main()
    {
        // Code Smell: Magic Number
        // Probleem: De getallen "a", "b", en "c" worden direct in de code gebruikt zonder uitleg waarom deze specifieke keuzes zijn.
        // Mogelijke Nadeel: Het is moeilijk te begrijpen waarom deze antwoorden specifiek zijn, en het kan lastig zijn om ze aan te passen zonder de hele code te doorlopen.
        // Oplossing: Gebruik een Enum of constante variabelen om de antwoordopties duidelijker te maken.
        // Refactoring Techniek: Replace Magic Number with Named Constant.

        // Definieer de vragen, opties en correcte antwoorden
        var vragen = new List<string>
        {
            "Vraag 1: Wat is 1 + 1?\n(a) 1\n(b) 2\n(c) 3",
            "Vraag 2: Wat is 5 - 3?\n(a) 1\n(b) 2\n(c) 3",
            "Vraag 3: Wat is 7 * 2?\n(a) 12\n(b) 14\n(c) 16",
            "Vraag 4: Wat is 9 / 3?\n(a) 2\n(b) 3\n(c) 4",
            "Vraag 5: Wat is 8 + 4?\n(a) 10\n(b) 12\n(c) 14"
        };

        // Code Smell: Inconsistent Naming
        // Probleem: De naam "antwoorden" is niet consistent met de naam van de andere lijsten.
        // Mogelijke Nadeel: Het kan verwarrend zijn, vooral voor andere ontwikkelaars die de code later lezen.
        // Oplossing: Geef de lijst een naam die consistent is met de betekenis, bijvoorbeeld "correcteAntwoorden".
        // Refactoring Techniek: Rename Variables to Improve Clarity.

        var antwoorden = new List<string> { "b", "c", "b", "b", "b" }; // Correcte antwoorden

        var gebruikersAntwoorden = new List<string>(); // Lijst om gebruikersantwoorden op te slaan
        int score = 0;

        // Loop door de vragen en vraag de gebruiker om antwoorden
        for (int i = 0; i < vragen.Count; i++)
        {
            Console.WriteLine(vragen[i]);
            Console.Write("Voer je antwoord in (a, b, c): ");
            string antwoord = Console.ReadLine().ToLower();

            // Code Smell: Duplicated Code
            // Probleem: De code om de antwoorden te controleren en het resultaat op te slaan is herhaald.
            // Mogelijke Nadeel: Het maakt de code moeilijker te onderhouden, omdat wijzigingen op meerdere plaatsen moeten worden doorgevoerd.
            // Oplossing: Maak een aparte functie voor het controleren van de antwoorden.
            // Refactoring Techniek: Extract Method.

            // Controleer of het antwoord juist is
            if (antwoord == antwoorden[i])
            {
                score++;
                gebruikersAntwoorden.Add($"Vraag {i + 1}: Goed");
            }
            else
            {
                gebruikersAntwoorden.Add($"Vraag {i + 1}: Fout");
            }
        }

        // Toon het overzicht van antwoorden en score
        Console.WriteLine("\nOverzicht van je antwoorden:");
        foreach (var resultaat in gebruikersAntwoorden)
        {
            Console.WriteLine(resultaat);
        }

        Console.WriteLine($"\nJe totale score is: {score} van de {vragen.Count} vragen.");
    }
}