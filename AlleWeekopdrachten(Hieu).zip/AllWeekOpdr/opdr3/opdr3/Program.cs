﻿using System;

namespace HogerLagerSpel
{
    class Program
    {
        static void Main(string[] args)
        {
            // Code Smell: Lange Methode (Long Method)
            // Probleem: De logica voor het spel zit in één lange methode.
            // Mogelijke Nadeel: Moeilijk te testen, te onderhouden en uit te breiden.
            // Oplossing: Verdeel de logica in kleinere, herbruikbare methoden.
            // Refactoring Techniek: Extract Method.

            int geheimNummer = Random.Shared.Next(1, 100);
            int poging = 0;
            bool geraden = false;

            Console.WriteLine("Welkom bij het Hoger-Lager Spel!");
            Console.WriteLine("Raad het geheime getal tussen 1 en 99.");

            // Code Smell: Repetitieve Code
            // Probleem: De validatie van invoer wordt meerdere keren herhaald.
            // Mogelijke Nadeel: Moeilijk te onderhouden en kan fouten veroorzaken bij wijzigingen.
            // Oplossing: Verplaats de invoer- en validatiecode naar een aparte methode.
            // Refactoring Techniek: Extract Method.

            while (!geraden)
            {
                Console.Write("Voer je gok in: ");
                string input = Console.ReadLine();

                if (int.TryParse(input, out poging))
                {
                    if (poging >= 1 && poging <= 99)
                    {
                        if (poging < geheimNummer)
                        {
                            Console.WriteLine("Hoger!");
                        }
                        else if (poging > geheimNummer)
                        {
                            Console.WriteLine("Lager!");
                        }
                        else
                        {
                            Console.WriteLine($"Gefeliciteerd! Je hebt het juiste getal {geheimNummer} geraden!");
                            geraden = true;
                        }
                    }
                    else
                    {
                        Console.WriteLine("Ongeldige invoer. Voer een getal tussen 1 en 99 in.");
                    }
                }
                else
                {
                    Console.WriteLine("Ongeldige invoer. Voer een geldig getal in.");
                }
            }

            Console.WriteLine("Bedankt voor het spelen!");
        }
    }
}