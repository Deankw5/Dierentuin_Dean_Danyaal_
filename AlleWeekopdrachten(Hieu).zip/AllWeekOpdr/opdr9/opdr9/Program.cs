﻿//OPDRACHT9
using System;

class Program
{
    static void Main()
    {
        // Code Smell: Magic Number
        // Probleem: De getallen 0, 50, 60, 75, 90 worden direct in de code gebruikt zonder uitleg waarom deze specifiek zijn.
        // Mogelijke Nadeel: Het is moeilijk te begrijpen waarom deze drempels belangrijk zijn, en het kan lastig zijn om ze aan te passen zonder de hele code te doorlopen.
        // Oplossing: Gebruik constante variabelen voor de drempels.
        // Refactoring Techniek: Replace Magic Number with Named Constant.

        // Vraag de gebruiker om een score in te voeren
        Console.Write("Voer een score in tussen 0 en 100: ");
        int score = int.Parse(Console.ReadLine());

        // Controleer of de score binnen het geldige bereik valt
        if (score < 0 || score > 100)
        {
            Console.WriteLine("De score moet tussen 0 en 100 liggen.");
            return; // Stop het programma als de score buiten het bereik valt
        }

        // Code Smell: Ternary Operator Complexiteit
        // Probleem: De ternary operator wordt gebruikt om meerdere niveaus van keuzes te maken, wat de leesbaarheid kan verminderen.
        // Mogelijke Nadeel: Het kan moeilijk zijn om te begrijpen wat er gebeurt, vooral als er meerdere lagen van ternary operators zijn.
        // Oplossing: Gebruik een serie `if`-verklaringen in plaats van een complexe ternary operator.
        // Refactoring Techniek: Replace Nested Ternary with Conditional Statements.

        // Gebruik de ternary operator om de beoordeling te bepalen
        string beoordeling = score < 50 ? "Slecht" :
                             score < 60 ? "Matig" :
                             score < 75 ? "Voldoende" :
                             score < 90 ? "Goed" :
                                          "Uitstekend";

        // Print de beoordeling
        Console.WriteLine("Beoordeling: " + beoordeling);
    }
}