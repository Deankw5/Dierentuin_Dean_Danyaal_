﻿using System;

class Program
{
    static void Main()
    {
        int count = 0; // Tel het aantal gevonden priemgetallen
        int number = 2; // Begin bij het eerste priemgetal

        // Code Smell: Oneindige lus zonder duidelijke stopconditie (Infinite Loop)
        // Probleem: De while-lus is oneindig, maar wordt gecontroleerd met een break statement.
        // Mogelijke Nadeel: De stopconditie is afhankelijk van het aantal priemgetallen, wat verwarrend kan zijn.
        // Oplossing: Gebruik een expliciete loop met een conditie gebaseerd op het aantal priemgetallen.
        // Refactoring Techniek: Replace Loop with Conditional.

        while (true) // Oneindige lus, zal worden beÃ«indigd met 'break'
        {
            // Controleer of het huidige getal een priemgetal is
            if (IsPrime(number))
            {
                // Print het priemgetal
                Console.WriteLine(number);

                // Verhoog de teller van gevonden priemgetallen
                count++;

                // Stop de lus als we 10 priemgetallen hebben gevonden
                if (count >= 10)
                {
                    break;
                }
            }

            // Ga verder met het volgende getal
            number++;
        }
    }

    // Methode om te controleren of een getal een priemgetal is
    // Code Smell: Lange methode (Long Method)
    // Probleem: De IsPrime methode is verantwoordelijk voor te veel logica.
    // Mogelijke Nadeel: Moeilijk te onderhouden en uit te breiden.
    // Oplossing: Verdeel de logica in kleinere, herbruikbare methoden.
    // Refactoring Techniek: Extract Method.

    static bool IsPrime(int number)
    {
        if (number <= 1) return false;
        if (number <= 3) return true;
        if (number % 2 == 0 || number % 3 == 0) return false;

        for (int i = 5; i * i <= number; i += 6)
        {
            if (number % i == 0 || number % (i + 2) == 0)
                return false;
        }

        return true;
    }
}