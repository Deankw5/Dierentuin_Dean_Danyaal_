﻿//OPDRACHT5
using System;

class Program
{
    static void Main()
    {
        // Loop van 1 tot en met 100
        for (int i = 1; i <= 100; i++)
        {
            // Code Smell: Lange Methode (Long Method)
            // Probleem: De logica voor het afdrukken van "Fizz", "Buzz", of het getal zelf zit in één grote methode.
            // Mogelijke Nadeel: Moeilijk te onderhouden en uit te breiden.
            // Oplossing: Verdeel de logica in kleinere methoden.
            // Refactoring Techniek: Extract Method.

            // Controleer of het getal een veelvoud is van zowel 3 als 5
            if (i % 3 == 0 && i % 5 == 0)
            {
                Console.WriteLine("FizzBuzz");
            }
            // Code Smell: Herhaling van vergelijkbare logica (Duplicated Code)
            // Probleem: De controles voor 3 en 5 zijn gescheiden, maar hetzelfde patroon herhaalt zich.
            // Mogelijke Nadeel: Moeilijker te onderhouden bij wijzigingen, code is minder flexibel.
            // Oplossing: Refactor de logica zodat het eenvoudig is om de string te genereren.
            // Refactoring Techniek: Replace Nested Conditional with Guard Clauses.

            // Controleer of het getal een veelvoud is van 3
            else if (i % 3 == 0)
            {
                Console.WriteLine("Fizz");
            }
            // Controleer of het getal een veelvoud is van 5
            else if (i % 5 == 0)
            {
                Console.WriteLine("Buzz");
            }
            // Als geen van bovenstaande voorwaarden waar is, print het getal
            else
            {
                Console.WriteLine(i);
            }
        }
    }
}