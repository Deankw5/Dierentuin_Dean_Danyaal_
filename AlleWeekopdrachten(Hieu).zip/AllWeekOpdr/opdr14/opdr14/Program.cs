﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Voer een positief geheel getal in (N): ");
        string input = Console.ReadLine();

        // Code Smell: De invoervalidatie wordt direct in de Main uitgevoerd.
        // Probleem: De logica voor de invoervalidatie is herhalend en moeilijk opnieuw te gebruiken.
        // Mogelijk Nadeel: Als er meerdere invoervalidaties nodig zijn, moet de code mogelijk dupliceren.
        // Oplossing: Verplaats de invoervalidatie naar een aparte methode voor herbruikbaarheid en eenvoudiger testen.
        // Refactoring Techniek: **Extract Method** - Verplaats de validatie naar een aparte methode.

        if (int.TryParse(input, out int N) && N > 0)
        {
            FizzBuzzBang(N);
        }
        else
        {
            Console.WriteLine("Ongeldige invoer. Voer een positief geheel getal in.");
        }
    }

    static void FizzBuzzBang(int N)
    {
        // Code Smell: De logica voor het bepalen van "Fizz", "Buzz", en "Bang" is ingebouwd in de loop zelf.
        // Probleem: De logica is moeilijk te testen en kan moeilijk worden aangepast als er een verandering in de regels komt.
        // Mogelijk Nadeel: Moeilijker om nieuwe regels of uitbreidingen toe te voegen zonder de hele methode te wijzigen.
        // Oplossing: Maak een aparte methode om de "FizzBuzzBang" logica te berekenen en gebruik die in de loop.
        // Refactoring Techniek: **Extract Method** - Splits de logica in een aparte methode.

        for (int i = 1; i <= N; i++)
        {
            // Code Smell: De string concatenatie in de loop maakt de leesbaarheid minder en de logica is moeilijk te volgen.
            // Probleem: Als er een fout optreedt in de samenstelling van de output, is het moeilijk om te debuggen.
            // Mogelijk Nadeel: Moeilijker aan te passen als je meerdere nieuwe termen toevoegt (bijvoorbeeld "Whizz").
            // Oplossing: Maak een aparte methode die de juiste string voor "Fizz", "Buzz", en "Bang" combineert en retourneert.
            // Refactoring Techniek: **Extract Method** - Maak een aparte methode voor het genereren van de uitvoer string.

            string result = "";

            if (i % 3 == 0)
                result += "Fizz";
            if (i % 5 == 0)
                result += "Buzz";
            if (i % 7 == 0)
                result += "Bang";

            Console.WriteLine(string.IsNullOrEmpty(result) ? i.ToString() : result);
        }
    }
}
