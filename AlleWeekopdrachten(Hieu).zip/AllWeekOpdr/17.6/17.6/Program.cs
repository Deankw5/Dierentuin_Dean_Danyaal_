﻿using System;
using System.Collections.Generic;

class Evenement
{
    // List om alle geldige kortingscodes op te slaan
    static List<string> geldigeKortingscodes = new List<string>
    {
        "P5CQV", "MVFHC", "P1WVX", "H15QA", "CKWX2", "B45SO",
        "1VRFH", "KSVQO", "WH83H", "AOZMT", "DSTCH", "VQ1H6",
        "C03GB", "1N9YM", "8W7F8"
    };
    /* 
       Code Smell: Primitive Obsession
       Probleem: Kortingscodes worden direct als strings beheerd, wat validatie en beheer bemoeilijkt.
       Mogelijk nadeel: Moeilijk uitbreidbaar als codes meer eigenschappen nodig hebben (bijv. vervaldatum).
       Oplossing: Maak een klasse om kortingscodes te representeren.
       Refactoring techniek: Replace Primitive with Object.
    */

    // HashSet om de gebruikte kortingscodes op te slaan
    static HashSet<string> gebruikteKortingscodes = new HashSet<string>();
    /* 
       Code Smell: Inconsistent Data Structure
       Probleem: Verschillende datastructuren (List en HashSet) maken het moeilijk om logica te centraliseren.
       Mogelijk nadeel: Complexere code door duplicatie van validatielogica.
       Oplossing: Combineer beide structuren in één klasse of datastructuur.
       Refactoring techniek: Encapsulate Collection.
    */

    static void Main()
    {
        Console.WriteLine("Voer een kortingscode in:");

        while (true)
        {
            string ingevoerdeCode = Console.ReadLine().ToUpper();  // Lees de ingevoerde code en zet deze om naar hoofdletters
            /* 
               Code Smell: Repeated Processing
               Probleem: Elke invoer wordt handmatig omgezet naar hoofdletters.
               Mogelijk nadeel: Kan leiden tot inconsistenties of fouten bij complexere invoer.
               Oplossing: Verplaats de invoerverwerking naar een aparte methode.
               Refactoring techniek: Extract Method.
            */

            // Controleer of de gebruiker "exit" typt om het programma te verlaten
            if (ingevoerdeCode == "EXIT")
            {
                break;
            }

            // Controleer of de kortingscode geldig is (staat in de List)
            if (geldigeKortingscodes.Contains(ingevoerdeCode))
            {
                /* 
                   Code Smell: Duplicate Code
                   Probleem: Validatie of een code geldig en ongebruikt is, gebeurt op meerdere plekken.
                   Mogelijk nadeel: Bij wijzigingen in validatielogica moeten meerdere delen worden aangepast.
                   Oplossing: Centraliseer validatie in een methode of klasse.
                   Refactoring techniek: Consolidate Conditional Expression.
                */

                // Controleer of de kortingscode al in de HashSet staat (al gebruikt)
                if (gebruikteKortingscodes.Contains(ingevoerdeCode))
                {
                    Console.WriteLine($"Kortingscode {ingevoerdeCode} is al gebruikt.");
                }
                else
                {
                    Console.WriteLine($"Kortingscode {ingevoerdeCode} is geldig. De code is nu gemarkeerd als gebruikt.");
                    gebruikteKortingscodes.Add(ingevoerdeCode);  // Voeg de code toe aan de set van gebruikte codes
                }
            }
            else
            {
                Console.WriteLine($"Kortingscode {ingevoerdeCode} is ongeldig.");
            }

            Console.WriteLine("\nVoer een nieuwe kortingscode in (of type 'exit' om af te sluiten):");
        }
    }
}
