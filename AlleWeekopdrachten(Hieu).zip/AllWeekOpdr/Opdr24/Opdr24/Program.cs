﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;

public class Program
{
    // De queue die door meerdere threads wordt gedeeld
    private static Queue<string> queue = new Queue<string>();

    // Mutex om gelijktijdige toegang te beschermen
    private static Mutex mutex = new Mutex();

    // Functie om items aan de queue toe te voegen
    public static void AddItems()
    {
        for (int i = 0; i < 10; i++)
        {
            queue.Enqueue($"Item {i}");
        }
    }
    // Code Smell:Direct gebruik van een gedeelde queue kan leiden tot race conditions.
    // Functie die door de threads wordt uitgevoerd om items uit de queue te lezen en naar de console te schrijven
    public static void ProcessItems()
    {
        while (true)
        {
            mutex.WaitOne(); // Verkrijg de Mutex om de queue te gebruiken

            // Controleer of er nog items in de queue zijn
            if (queue.Count > 0)
            {
                var item = queue.Dequeue();
                Console.WriteLine($"Processed: {item}");
            }
            mutex.ReleaseMutex(); // Geef de Mutex weer vrij

            // Stop de thread als er geen items meer zijn
            if (queue.Count == 0)
                break;

            // Simuleer een vertraging
            Thread.Sleep(100);
        }
    }

    public static void Main(string[] args)
    {
        // Voeg items toe aan de queue
        AddItems();

        // Start meerdere threads om items uit de queue te lezen
        List<Thread> threads = new List<Thread>();
        for (int i = 0; i < 5; i++)
        {
            Thread t = new Thread(ProcessItems);
            threads.Add(t);
            t.Start();
        }

        // Wacht tot alle threads klaar zijn
        foreach (var thread in threads)
        {
            thread.Join();
        }

        Console.WriteLine("Processing completed with Mutex synchronization.");
    }
}
