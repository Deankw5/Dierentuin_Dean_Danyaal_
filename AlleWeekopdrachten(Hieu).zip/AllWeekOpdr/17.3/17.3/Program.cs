﻿using System;
using System.Collections.Generic;

class Tekstverwerker
{
    static Stack<string> undoStack = new Stack<string>();  // Opslaan van de vorige tekststaten
    static Stack<string> redoStack = new Stack<string>();  // Opslaan van tekststaten voor opnieuw doen
    static string huidigeTekst = string.Empty;  // De huidige staat van de tekst

    static void Main()
    {
        Console.WriteLine("Tekstverwerker gestart. Typ tekst, gebruik CTRL+Z voor ongedaan maken en CTRL+Y voor opnieuw doen.");
        Console.WriteLine("Om te stoppen, type 'exit' en druk op enter.");

        while (true)
        {
            var toets = Console.ReadKey(intercept: true);  // Lees toetsaanslagen zonder ze direct weer te geven

            // CTRL+Z voor ongedaan maken
            if (toets.Modifiers == ConsoleModifiers.Control && toets.Key == ConsoleKey.Z)
            {
                OngedaanMaken();
            }
            // CTRL+Y voor opnieuw doen
            else if (toets.Modifiers == ConsoleModifiers.Control && toets.Key == ConsoleKey.Y)
            {
                OpnieuwDoen();
            }
            // Beëindigen van programma
            else if (toets.Key == ConsoleKey.Enter && huidigeTekst.ToLower() == "exit")
            {
                break;
            }
            // Tekst invoer verwerken
            else
            {
                VerwerkInvoer(toets.KeyChar.ToString());
            }

            Console.Clear();  // Maak het scherm schoon om de tekst opnieuw weer te geven
            Console.WriteLine("Huidige tekst: " + huidigeTekst);
        }
    }

    // Methode voor het verwerken van nieuwe tekstinvoer
    static void VerwerkInvoer(string invoer)
    {
        // Code Smell: Primitive Obsession
        // Probleem: Gebruik van een string om tekststatus te beheren is eenvoudig, maar niet flexibel.
        // Mogelijk nadeel: Moeilijk uit te breiden of aan te passen aan complexe vereisten.
        // Oplossing: Introduceer een klasse om tekststatus te representeren.
        // Refactoring techniek: Replace Primitive with Object.
        if (char.IsLetter(invoer, 0))  // Alleen letters verwerken
        {
            // Voeg de huidige staat toe aan de undo stack
            undoStack.Push(huidigeTekst);

            // Omdat er een nieuwe bewerking is gedaan, moeten we de redo stack legen
            redoStack.Clear();

            // Voeg het nieuwe karakter toe aan de huidige tekst
            huidigeTekst += invoer;
        }
    }

    // Methode voor ongedaan maken (CTRL+Z)
    static void OngedaanMaken()
    {
        // Code Smell: Conditional Complexity
        // Probleem: Controle op lege stack wordt herhaald in meerdere methoden.
        // Mogelijk nadeel: Toename van duplicatie en moeilijk onderhoudbare code.
        // Oplossing: Verplaats controle naar een aparte helpermethode.
        // Refactoring techniek: Extract Method.
        if (undoStack.Count > 0)
        {
            // Voeg de huidige staat toe aan de redo stack voor het geval we opnieuw willen doen
            redoStack.Push(huidigeTekst);

            // Herstel de vorige tekststaat vanuit de undo stack
            huidigeTekst = undoStack.Pop();
        }
    }

    // Methode voor opnieuw doen (CTRL+Y)
    static void OpnieuwDoen()
    {
        // Code Smell: Duplicated Code
        // Probleem: Logica voor stackbeheer is identiek aan OngedaanMaken(), maar met stacks omgedraaid.
        // Mogelijk nadeel: Wijzigingen in de ene methode moeten worden gerepliceerd in de andere.
        // Oplossing: Verplaats gedeelde logica naar een algemene methode.
        // Refactoring techniek: Extract Method.
        if (redoStack.Count > 0)
        {
            // Voeg de huidige staat toe aan de undo stack
            undoStack.Push(huidigeTekst);

            // Herstel de laatst ongedaan gemaakte tekst vanuit de redo stack
            huidigeTekst = redoStack.Pop();
        }
    }
}
