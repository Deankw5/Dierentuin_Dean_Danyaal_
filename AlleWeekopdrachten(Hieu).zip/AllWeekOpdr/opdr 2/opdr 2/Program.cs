﻿using System;

namespace CijferBeoordeling
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Vul een cijfer in tussen 1,0 en 10,0:");
            string input = Console.ReadLine();

            if (double.TryParse(input, out double number))
            {
                // Code Smell: Lange Methode (Long Method)
                // Probleem: De logica voor de cijferbeoordeling zit in één lange methode.
                // Mogelijke Nadeel: Moeilijk te testen, te onderhouden en uit te breiden.
                // Oplossing: Verdeel de logica in kleinere, herbruikbare methoden.
                // Refactoring Techniek: Extract Method.

                // Controleer of het getal binnen de geldige range valt
                if (number >= 1.0 && number <= 10.0)
                {
                    // Code Smell: Repetitieve Code
                    // Probleem: Herhaalde if-else statements voor cijferbeoordelingen.
                    // Mogelijke Nadeel: Moeilijk te onderhouden als de beoordelingslogica verandert.
                    // Oplossing: Gebruik een array of een dictionary om beoordelingen op te slaan.
                    // Refactoring Techniek: Replace Conditional with Table.

                    // Gebruik if-else om de beoordeling te bepalen
                    if (number >= 9.0)
                    {
                        Console.WriteLine("Uitmuntend");
                    }
                    else if (number >= 8.0)
                    {
                        Console.WriteLine("Zeer goed");
                    }
                    else if (number >= 7.0)
                    {
                        Console.WriteLine("Goed");
                    }
                    else if (number >= 6.0)
                    {
                        Console.WriteLine("Voldoende");
                    }
                    else if (number >= 5.0)
                    {
                        Console.WriteLine("Bijna voldoende");
                    }
                    else if (number >= 4.0)
                    {
                        Console.WriteLine("Onvoldoende");
                    }
                    else if (number >= 3.0)
                    {
                        Console.WriteLine("Matig");
                    }
                    else if (number >= 2.0)
                    {
                        Console.WriteLine("Slecht");
                    }
                    else if (number >= 1.0)
                    {
                        Console.WriteLine("Zeer slecht");
                    }
                }
                else
                {
                    Console.WriteLine("Ongeldige invoer. Voer een getal tussen 1,0 en 10,0 in.");
                }
            }
            else
            {
                Console.WriteLine("Dit is geen Cijfer");
            }
        }
    }
}