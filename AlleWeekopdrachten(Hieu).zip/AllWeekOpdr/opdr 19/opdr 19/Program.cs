﻿using System;
using System.Collections.Generic;
using System.Linq;

// 1. Car Class (Weekopdracht 19-1)
public class Car
{
    public string Brand { get; set; }
    public string Type { get; set; }
    public string Color { get; set; }
    public string Owner { get; set; }
    public int Year { get; set; }
    public string VIN { get; set; }

    // Constructor voor Car
    public Car(string brand, string type, string color, string owner, int year, string vin)
    {
        Brand = brand;
        Type = type;
        Color = color;
        Owner = owner;
        Year = year;
        VIN = vin;
    }

    // Functie om de informatie over de auto weer te geven
    public void DisplayInfo()
    {
        Console.WriteLine($"Brand: {Brand}");
        Console.WriteLine($"Type: {Type}");
        Console.WriteLine($"Color: {Color}");
        Console.WriteLine($"Owner: {Owner}");
        Console.WriteLine($"Year: {Year}");
        Console.WriteLine($"VIN: {VIN}");
        Console.WriteLine(); // Extra lege regel
    }
}

// 2. Garage Class (Weekopdracht 19-2)
public class Garage
{
    public List<Car> Cars { get; set; }

    // Constructor voor Garage
    public Garage()
    {
        Cars = new List<Car>();
    }

    // Functie om een auto toe te voegen aan de garage
    public void AddCar(Car car)
    {
        Cars.Add(car);
    }

    // Functie om een auto uit de garage te verwijderen
    public void RemoveCar(string vin)
    {
        var carToRemove = Cars.FirstOrDefault(c => c.VIN == vin);
        if (carToRemove != null)
        {
            Cars.Remove(carToRemove);
            Console.WriteLine($"Car with VIN {vin} removed.");
        }
        else
        {
            Console.WriteLine($"Car with VIN {vin} not found.");
        }
    }

    // Functie om de lijst van auto's in de garage weer te geven
    public void DisplayList()
    {
        if (Cars.Count == 0)
        {
            Console.WriteLine("No cars in this garage.");
            return;
        }
        Console.WriteLine("Cars in the Garage:");
        foreach (var car in Cars)
        {
            car.DisplayInfo();
        }
    }

    // Optionele functie om de lijst van auto's te sorteren op brand, model, en jaar
    public void SortCars()
    {
        Cars = Cars.OrderBy(c => c.Brand).ThenBy(c => c.Type).ThenBy(c => c.Year).ToList();
        Console.WriteLine("Cars have been sorted by brand, type, and year.");
    }
}

// 3. W-Park Class (Weekopdracht 19-3)
public class WPark
{
    public List<Garage> Garages { get; set; }
    public string Manager { get; set; }
    public int MaxParkingSpaces { get; set; }
    public int AvailableSpaces { get; set; }

    // Constructor voor WPark
    public WPark(string manager, int maxParkingSpaces)
    {
        Garages = new List<Garage>();
        Manager = manager;
        MaxParkingSpaces = maxParkingSpaces;
        AvailableSpaces = maxParkingSpaces;
    }

    // Functie om een garage toe te voegen aan W-Park
    public void AddGarage(Garage garage)
    {
        Garages.Add(garage);
        Console.WriteLine("New garage added.");
    }

    // Functie om een garage uit W-Park te verwijderen
    public void RemoveGarage(Garage garage)
    {
        if (Garages.Remove(garage))
        {
            Console.WriteLine("Garage removed.");
        }
        else
        {
            Console.WriteLine("Garage not found.");
        }
    }

    // Functie om een auto toe te voegen aan een garage via de garage naam
    public void AddCarToGarage(string garageName, Car car)
    {
        var garage = Garages.FirstOrDefault(g => g.ToString() == garageName);
        if (garage != null)
        {
            garage.AddCar(car);
            Console.WriteLine($"Car added to garage {garageName}.");
        }
        else
        {
            Console.WriteLine("Garage not found.");
        }
    }

    // Functie om een auto uit een garage te verwijderen via de garage naam
    public void RemoveCarFromGarage(string garageName, string vin)
    {
        var garage = Garages.FirstOrDefault(g => g.ToString() == garageName);
        if (garage != null)
        {
            garage.RemoveCar(vin);
        }
        else
        {
            Console.WriteLine("Garage not found.");
        }
    }

    // Functie om een lijst van garages en auto's weer te geven
    public void DisplayList()
    {
        Console.WriteLine("Garages in W-Park:");
        foreach (var garage in Garages)
        {
            Console.WriteLine("Garage:");
            garage.DisplayList();
        }
    }
}

// Main Program
class Program
{
    static void Main(string[] args)
    {
        // Weekopdracht 19-1: Maak een aantal auto's aan
        Car car1 = new Car("Toyota", "Corolla", "Red", "Alice", 2018, "VIN123456");
        Car car2 = new Car("Ford", "Focus", "Blue", "Bob", 2020, "VIN789101");
        Car car3 = new Car("BMW", "X5", "Black", "Charlie", 2022, "VIN112233");

        // Weekopdracht 19-2: Maak een garage aan en voeg auto's toe
        Garage garage1 = new Garage();
        garage1.AddCar(car1);
        garage1.AddCar(car2);

        Garage garage2 = new Garage();
        garage2.AddCar(car3);

        // Weekopdracht 19-3: Maak een W-Park en voeg garages toe
        WPark wpark = new WPark("John Doe", 50);
        wpark.AddGarage(garage1);
        wpark.AddGarage(garage2);

        // Toon de informatie over de garages en auto's in W-Park
        wpark.DisplayList();

        // Verwijder een auto uit de garage en toon opnieuw de lijst
        garage1.RemoveCar("VIN123456");
        wpark.DisplayList();

        // Sorteren van de auto's op merk, model en jaar
        garage1.SortCars();
        wpark.DisplayList();
    }
}
