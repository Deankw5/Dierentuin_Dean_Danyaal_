﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace ContainerTerminal
{
    // De Container-klasse wordt gebruikt om een container te identificeren met een uniek nummer

    class Container
    {
        public string ContainerNumber { get; private set; }

        public Container(string containerNumber)
        {
            ContainerNumber = containerNumber; // Probleem: Mogelijke overbodige klasse bij kleine functionaliteit
        }

        public override string ToString()
        {
            return ContainerNumber; // Refactoring: Overweeg Inline Class als deze klasse verder geen logica bevat
        }
    }

    class Terminal
    {
        private const int MaxStacks = 10;  // Probleem: Magic Numbers
        private const int MaxHeight = 5;   // Probleem: Magic Numbers
        private List<Stack<Container>> stacks; // Probleem: Verborgen afhankelijkheden (bijv. hardcoded limieten)

        public Terminal()
        {
            stacks = new List<Stack<Container>>(MaxStacks); // Refactoring: Introduce Parameter Object voor configuratie
            for (int i = 0; i < MaxStacks; i++)
            {
                stacks.Add(new Stack<Container>());
            }
        }

        public void AddContainer(Container container)
        {
            for (int i = 0; i < MaxStacks; i++)
            {
                if (stacks[i].Count < MaxHeight)
                {
                    stacks[i].Push(container);
                    return; // Probleem: Geen foutmelding als alle stapels vol zijn
                }
            }
            // Refactoring: Introduce Exception of Return Value om falen aan te geven
        }

        public void RetrieveContainer(string containerNumber)
        {
            for (int i = 0; i < MaxStacks; i++)
            {
                var stack = stacks[i];
                if (stack.Any(c => c.ContainerNumber == containerNumber))
                {
                    Stack<Container> tempStack = new Stack<Container>();

                    while (stack.Peek().ContainerNumber != containerNumber)
                    {
                        tempStack.Push(stack.Pop()); // Probleem: Herhalende logica voor manipulatie van stapels
                    }

                    Container retrievedContainer = stack.Pop();

                    PlaceContainersBack(tempStack, i); // Refactoring: Extract Method voor duidelijkheid en herbruikbaarheid
                    return;
                }
            }
        }

        private void PlaceContainersBack(Stack<Container> tempStack, int originalStackIndex)
        {
            while (tempStack.Count > 0)
            {
                Container containerToPlace = tempStack.Pop();

                bool placed = false;
                for (int i = 0; i < MaxStacks; i++)
                {
                    if (i != originalStackIndex && stacks[i].Count < MaxHeight)
                    {
                        stacks[i].Push(containerToPlace);
                        placed = true;
                        break;
                    }
                }

                if (!placed)
                {
                    stacks[originalStackIndex].Push(containerToPlace); // Probleem: Geen controle op overschrijding van limiet
                }
            }
            // Refactoring: Replace Nested Loops met andere datastructuur of logica
        }

        public void PrintStatus()
        {
            for (int i = 0; i < MaxStacks; i++)
            {
                Console.Write($"Stapel {i + 1}: ");
                Console.WriteLine(string.Join(", ", stacks[i].Select(container => container.ToString()))); // Probleem: ToString afhankelijkheid
            }
            // Refactoring: Introduce Formatter Object voor betere weergave
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Terminal terminal = new Terminal();

            string[] containers = new string[]
            {
                "QVDM8009762", "CJIG1905934", "FGCM4664607", "CFLG6697633", "EQOD4660076", "PGLD2285677",
                "IISX5619237", "QMNU0970619", "SXKB8127565", "WBGZ9043382", "BVLZ9518548", "ZNSF2844985",
                "MRMV5005868", "PSWG7783254", "MYXT5104082", "GATM3160561", "XTXY3685126", "JFGQ5602926",
                "ICKQ5740110", "LLEN8095860", "DJQQ9473760", "MLUL9881099", "ZVZT6648738", "ZCFF1692285",
                "KDQD6427718"
            };

            foreach (string containerNumber in containers)
            {
                Container container = new Container(containerNumber); // Refactoring: Factory Method als Container-complexiteit groeit
                terminal.AddContainer(container);
            }

            Container newContainer = new Container("NEWCONTAINER1234");
            terminal.AddContainer(newContainer);

            terminal.PrintStatus();

            Console.WriteLine("\nOphalen van container 'XTXY3685126':");
            terminal.RetrieveContainer("XTXY3685126");

            terminal.PrintStatus();
        }
    }
}
