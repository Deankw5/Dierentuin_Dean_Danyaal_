﻿using System;
using System.Collections.Generic;

// Abstracte base class voor materiaal
public abstract class Material
{
    public string Title { get; set; }
    public string Description { get; set; }

    // Abstracte methode voor het verkrijgen van materiaal details
    public abstract string GetMaterialDetails();

    // Override van ToString voor gepersonaliseerde uitvoer
    public override string ToString()
    {
        return $"{Title} - {Description}";
    }
}

// Concrete class voor Book
public class Book : Material
{
    public string Author { get; set; }
    public int Pages { get; set; }

    public Book(string title, string description, string author, int pages)
    {
        Title = title;
        Description = description;
        Author = author;
        Pages = pages;
    }

    public override string GetMaterialDetails()
    {
        return $"Book: {Title}, Author: {Author}, Pages: {Pages}";
    }

    public override string ToString()
    {
        return $"Book: {Title}, Author: {Author}, Pages: {Pages}";
    }
}

// Concrete class voor DigitalDocument
public class DigitalDocument : Material
{
    public string FileType { get; set; }
    public long FileSize { get; set; }

    public DigitalDocument(string title, string description, string fileType, long fileSize)
    {
        Title = title;
        Description = description;
        FileType = fileType;
        FileSize = fileSize;
    }

    public override string GetMaterialDetails()
    {
        return $"Document: {Title}, Type: {FileType}, Size: {FileSize}KB";
    }

    public override string ToString()
    {
        return $"Document: {Title}, Type: {FileType}, Size: {FileSize}KB";
    }
}

// Concrete class voor VideoCourse
public class VideoCourse : Material
{
    public string VideoUrl { get; set; }
    public int Duration { get; set; } // Duration in minutes

    public VideoCourse(string title, string description, string videoUrl, int duration)
    {
        Title = title;
        Description = description;
        VideoUrl = videoUrl;
        Duration = duration;
    }

    public override string GetMaterialDetails()
    {
        return $"Video Course: {Title}, URL: {VideoUrl}, Duration: {Duration} minutes";
    }

    public override string ToString()
    {
        return $"Video Course: {Title}, URL: {VideoUrl}, Duration: {Duration} minutes";
    }
}

// Abstracte base class voor User
public abstract class User
{
    public string Name { get; set; }
    public int Age { get; set; }

    public User(string name, int age)
    {
        Name = name;
        Age = age;
    }

    // Abstracte methode voor het verkrijgen van gebruikersdetails
    public abstract string GetUserDetails();

    // Override van ToString voor gepersonaliseerde uitvoer
    public override string ToString()
    {
        return $"{Name}, Age: {Age}";
    }
}

// Concrete class voor Teacher
public class Teacher : User
{
    public string Subject { get; set; }

    public Teacher(string name, int age, string subject) : base(name, age)
    {
        Subject = subject;
    }

    public override string GetUserDetails()
    {
        return $"Teacher: {Name}, Age: {Age}, Subject: {Subject}";
    }

    public override string ToString()
    {
        return $"Teacher: {Name}, Subject: {Subject}";
    }
}

// Concrete class voor Student
public class Student : User
{
    public string Grade { get; set; }

    public Student(string name, int age, string grade) : base(name, age)
    {
        Grade = grade;
    }

    public override string GetUserDetails()
    {
        return $"Student: {Name}, Age: {Age}, Grade: {Grade}";
    }

    public override string ToString()
    {
        return $"Student: {Name}, Grade: {Grade}";
    }
}

// Cursus class die gebruikers en materialen bevat
public class Course
{
    public string CourseName { get; set; }
    public List<User> Users { get; set; } = new List<User>();
    public List<Material> Materials { get; set; } = new List<Material>();

    public Course(string courseName)
    {
        CourseName = courseName;
    }

    // Voeg een gebruiker toe aan de cursus
    public void AddUser(User user)
    {
        Users.Add(user);
    }

    // Voeg materiaal toe aan de cursus
    public void AddMaterial(Material material)
    {
        Materials.Add(material);
    }

    // Toon cursusdetails
    public void DisplayCourseDetails()
    {
        Console.WriteLine($"Course: {CourseName}");
        Console.WriteLine("Users:");
        foreach (var user in Users)
        {
            Console.WriteLine(user.GetUserDetails());
        }

        Console.WriteLine("\nMaterials:");
        foreach (var material in Materials)
        {
            Console.WriteLine(material.GetMaterialDetails());
        }
    }
}

// Test van de applicatie
public class Program
{
    public static void Main(string[] args)
    {
        // Maak enkele gebruikers
        Teacher teacher1 = new Teacher("Dr. Smith", 45, "Mathematics");
        Student student1 = new Student("John Doe", 20, "A");

        // Maak enkele materialen
        Book book1 = new Book("C# Programming", "Learn C# in depth", "John Developer", 250);
        DigitalDocument doc1 = new DigitalDocument("C# Cheat Sheet", "Quick reference for C#", "PDF", 500);
        VideoCourse video1 = new VideoCourse("C# Basics", "Introductory course on C#", "http://example.com/video", 30);

        // Maak een cursus en voeg gebruikers en materialen toe
        Course course1 = new Course("C# Programming 101");
        course1.AddUser(teacher1);
        course1.AddUser(student1);
        course1.AddMaterial(book1);
        course1.AddMaterial(doc1);
        course1.AddMaterial(video1);

        // Toon cursusdetails
        course1.DisplayCourseDetails();

        // ToString testen
        Console.WriteLine("\nToString Test:");
        Console.WriteLine(teacher1);
        Console.WriteLine(student1);
        Console.WriteLine(book1);
        Console.WriteLine(doc1);
        Console.WriteLine(video1);
    }
}
