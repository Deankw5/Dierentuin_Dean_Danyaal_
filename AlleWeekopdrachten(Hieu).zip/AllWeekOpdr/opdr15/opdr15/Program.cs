﻿using System;
using System.Collections.Generic;

class Program
{
    // Iteratieve Methode
    static int FibonacciIteratief(int n)
    {
        // Code Smell: De logica is herhalend voor het berekenen van Fibonacci-nummers.
        // Probleem: Als we de logica voor Fibonacci berekeningen willen aanpassen, moeten we in meerdere methoden wijzigingen aanbrengen.
        // Mogelijk Nadeel: Code duplicatie in verschillende implementaties.
        // Oplossing: Verplaats de Fibonacci-berekeningslogica naar een aparte methode die door verschillende benaderingen wordt aangeroepen.
        // Refactoring Techniek: **Extract Method**

        if (n <= 0) return 0;
        if (n == 1) return 1;

        int a = 0, b = 1;
        for (int i = 2; i <= n; i++)
        {
            int temp = a + b;
            a = b;
            b = temp;
        }
        return b;
    }

    // Recursieve Methode
    static int FibonacciRecursief(int n)
    {
        // Code Smell: De recursieve methode heeft een inefficiëntie door meerdere herhalende berekeningen.
        // Probleem: De recursieve implementatie berekent Fibonacci-nummers herhaaldelijk voor dezelfde waarden, wat leidt tot exponentiële tijdcomplexiteit.
        // Mogelijk Nadeel: Grote invoerwaarden kunnen leiden tot stack overflow of lange rekentijden.
        // Oplossing: Overweeg het gebruik van memoization om herhalende berekeningen te vermijden.
        // Refactoring Techniek: **Memoization**

        if (n <= 0) return 0;
        if (n == 1) return 1;
        return FibonacciRecursief(n - 1) + FibonacciRecursief(n - 2);
    }

    // Memoization Methode
    static int FibonacciMemoization(int n, Dictionary<int, int> memo = null)
    {
        // Code Smell: Er is een afhankelijkheid van een dictionary die in elke recursieve oproep wordt doorgegeven.
        // Probleem: De memo dictionary kan groeien, maar wordt niet altijd opgeruimd of geoptimaliseerd.
        // Mogelijk Nadeel: Grote invoerwaarden kunnen nog steeds leiden tot geheugenproblemen door een grote memo dictionary.
        // Oplossing: Optimaliseer het geheugenbeheer of gebruik een andere datastructuur voor memoization die minder geheugen gebruikt.
        // Refactoring Techniek: **Optimize Memory Usage**

        if (memo == null) memo = new Dictionary<int, int>();

        if (memo.ContainsKey(n)) return memo[n];
        if (n <= 0) return 0;
        if (n == 1) return 1;

        memo[n] = FibonacciMemoization(n - 1, memo) + FibonacciMemoization(n - 2, memo);
        return memo[n];
    }

    // Tabulatie Methode
    static int FibonacciTabulatie(int n)
    {
        // Code Smell: Het gebruik van een array kan inefficiënt zijn voor zeer grote invoerwaarden.
        // Probleem: De array moet in zijn geheel worden opgeslagen, wat onnodig geheugen gebruikt voor grotere invoerwaarden.
        // Mogelijk Nadeel: Geheugenverbruik neemt lineair toe met de grootte van n.
        // Oplossing: Gebruik in plaats van een array alleen de laatste twee waarden om geheugen te besparen.
        // Refactoring Techniek: **Optimize Memory Usage**

        if (n <= 0) return 0;
        if (n == 1) return 1;

        int[] fib = new int[n + 1];
        fib[0] = 0;
        fib[1] = 1;

        for (int i = 2; i <= n; i++)
        {
            fib[i] = fib[i - 1] + fib[i - 2];
        }

        return fib[n];
    }

    static void Main()
    {
        int n = 10;

        Console.WriteLine($"Iteratieve Methode: {FibonacciIteratief(n)}");  // Output: 55
        Console.WriteLine($"Recursieve Methode: {FibonacciRecursief(n)}");  // Output: 55
        Console.WriteLine($"Memoization Methode: {FibonacciMemoization(n)}");  // Output: 55
        Console.WriteLine($"Tabulatie Methode: {FibonacciTabulatie(n)}");  // Output: 55
    }
}
