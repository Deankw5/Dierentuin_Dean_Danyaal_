﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;

public class StaffMember
{
    public string FullName { get; set; }
    public int Age { get; set; }
    public string Position { get; set; }
    public string Department { get; set; }
    public string StartDate { get; set; }

    // Constructor om een nieuw StaffMember object aan te maken
    public StaffMember(string fullName, int age, string position, string department, string startDate)
    {
        FullName = fullName;
        Age = age;
        Position = position;
        Department = department;
        StartDate = startDate;
    }
}

public class Program
{
    // Declareer een statisch Random object om vertraging te simuleren
    private static Random _random = new Random();

    // Method om een nieuw StaffMember object aan te maken
    public static StaffMember newStaffMember(string fullName, int age, string position, string department, string startDate)
    {
        return new StaffMember(fullName, age, position, department, startDate);
    }

    // Asynchrone functie om de gegevens van een personeelslid op te halen met vertraging
    public static async Task<StaffMember> GetStaffMemberAsync(string fullName, int age, string position, string department, string startDate)
    {
        // Simuleer een willekeurige vertraging tussen 1000 en 5000 milliseconden
        await Task.Delay(_random.Next(1000, 5000)); // Delay tussen 1000 ms en 5000 ms

        // Maak een nieuw StaffMember object met de gegevens
        return new StaffMember(fullName, age, position, department, startDate);
    }

    // Asynchrone functie die een lijst van 10 personeelsleden ophaalt en hun gegevens toont
    public static async Task GetAndDisplayStaffMembersAsync(List<string> staffMemberNames, List<StaffMember> staffMembers)
    {
        for (int i = 0; i < staffMemberNames.Count; i++)
        {
            var name = staffMemberNames[i];
            var staffMember = staffMembers[i];

            // Haal de gegevens van het personeelslid asynchroon op
            var staffDetails = await GetStaffMemberAsync(staffMember.FullName, staffMember.Age, staffMember.Position, staffMember.Department, staffMember.StartDate);

            // Toon de gegevens op het scherm (in dit geval de console)
            Console.WriteLine($"Name: {staffDetails.FullName}");
            Console.WriteLine($"Age: {staffDetails.Age}");
            Console.WriteLine($"Position: {staffDetails.Position}");
            Console.WriteLine($"Department: {staffDetails.Department}");
            Console.WriteLine($"Start Date: {staffDetails.StartDate}");
            Console.WriteLine("--------------------------");
        }
    }
    // Code smell: Initialisatie van stacks wordt herhaald
    // Mogelijk probleem: Geen foutafhandeling voor het asynchrone proces.
    // Oplossing: Voeg try-catch toe om eventuele fouten te loggen of een terugvalmechanisme te gebruiken.
    // Hoofdfunctie om de uitvoering te starten
    public static async Task Main(string[] args)
    {
        // Voorbeeldlijst van namen van personeelsleden
        List<string> staffMemberNames = new List<string>
        {
            "Alice Andersen", "Bob Brown", "Charlie Chapman", "Diana Douglas", "Evan Edwards",
            "Fiona Fisher", "George Green", "Hannah Harris", "Ian Irving"
        };

        // Voorbeeldlijst van StaffMember objecten
        List<StaffMember> staffMembers = new List<StaffMember>
        {
            newStaffMember("Alice Andersen", 30, "Software Ontwikkelaar", "IT", "01-03-2015"),
            newStaffMember("Bob Brown", 45, "Project Manager", "Marketing", "15-06-2010"),
            newStaffMember("Charlie Chapman", 28, "Data Analist", "Analyse", "23-09-2018"),
            newStaffMember("Diana Douglas", 35, "HR Manager", "Human Resources", "30-01-2012"),
            newStaffMember("Evan Edwards", 40, "Netwerkbeheerder", "IT", "19-05-2008"),
            newStaffMember("Fiona Fisher", 25, "Marketing Specialist", "Marketing", "01-07-2019"),
            newStaffMember("George Green", 32, "Product Manager", "Productontwikkeling", "17-11-2014"),
            newStaffMember("Hannah Harris", 38, "Sales Manager", "Verkoop", "12-04-2009"),
            newStaffMember("Ian Irving", 29, "Customer Support Medewerker", "Klantenservice", "29-02-2016")
        };

        // Haal en toon de gegevens van de personeelsleden asynchroon
        await GetAndDisplayStaffMembersAsync(staffMemberNames, staffMembers);
    }
}
