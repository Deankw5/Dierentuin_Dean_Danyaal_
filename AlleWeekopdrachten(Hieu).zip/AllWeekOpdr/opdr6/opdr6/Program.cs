﻿//OPDRACHT6
using System;
using System.Collections.Generic;

class Program
{
    static void Main()
    {
        // Definieer de lijst met namen
        List<string> namen = new List<string> { "Anna", "Bob", "Charlie", "Dave", "Eva", "Frank", "Grace", "Harry", "Ivy", "Jack" };

        // Code Smell: Lange Methode (Long Method)
        // Probleem: De logica voor het controleren van de lengte van de naam en het afdrukken zit in dezelfde loop.
        // Mogelijke Nadeel: Moeilijk te onderhouden en uit te breiden.
        // Oplossing: Verdeel de logica in kleinere methoden.
        // Refactoring Techniek: Extract Method.

        // Loop door de lijst met namen
        foreach (string names in namen)
        {
            // Code Smell: Inconsistentie in naamgeving (Inconsistent Naming)
            // Probleem: De gebruikte variabele naam "names" is in meervoud, maar het wordt gebruikt voor een enkele naam.
            // Mogelijke Nadeel: Kan verwarrend zijn voor de lezer van de code.
            // Oplossing: Gebruik een enkelvoudige naam voor de variabele.
            // Refactoring Techniek: Rename Variable.

            // Controleer of de naam minder dan 5 tekens lang is
            if (names.Length < 5)
            {
                // Print de naam
                Console.WriteLine(names);
            }
        }
    }
}