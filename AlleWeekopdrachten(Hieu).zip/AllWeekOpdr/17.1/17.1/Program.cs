﻿using System.Text;

namespace ConsoleVoorbeeld
{
    class Program
    {
        static void Main(string[] args)
        {
            // Code Smell: Magische Getallen
            // Probleem: De cijfers 1-10 zijn hardgecodeerd in de `switch`-case.
            // Mogelijke Nadeel: Moeilijker te begrijpen en aanpassen.
            // Oplossing: Gebruik beschrijvende constanten.
            // Refactoring Techniek: Replace Magic Number with Symbolic Constant.

            Console.WriteLine("vul cijfer in 1 tot 10");
            string input = Console.ReadLine();



            switch (int.TryParse(input, out int number) ? number : -1)
            {


                case 1:
                    Console.WriteLine("Zeer slecht");
                    break;
                case 2:
                    Console.WriteLine("Slecht");
                    break;
                case 3:
                    Console.WriteLine("Matig");
                    break;
                case 4:
                    Console.WriteLine("Onvoldoende");
                    break;
                case 5:
                    Console.WriteLine("Bijna voldoende");
                    break;
                case 6:
                    Console.WriteLine("Voldoende");
                    break;
                case 7:
                    Console.WriteLine("Ruim voldoende");
                    break;
                case 8:
                    Console.WriteLine("Goed");
                    break;
                case 9:
                    Console.WriteLine("Zeer goed");
                    break;
                case 10:
                    Console.WriteLine("Uitmuntend");
                    break;
                default:
                    Console.WriteLine("Ongeldige invoer. Voer een cijfer tussen 1 en 10 in.");
                    break;
            }
        }
    }
}
