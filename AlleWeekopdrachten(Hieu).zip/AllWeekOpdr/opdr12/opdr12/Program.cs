﻿using System;

class Program
{
    static void Main()
    {
        PrintGreeting();
        Calculator();
    }

    static void Calculator()
    {
        bool continueCalculating = true;

        while (continueCalculating)
        {
            Console.Clear();
            Console.WriteLine("Complexere Rekenmachine");
            Console.WriteLine("Kies een operatie: +, -, *, /, %, ^ (macht), sqrt (vierkantswortel), 18+ (kassa)");
            string operation = Console.ReadLine();

            double number1 = GetNumber("Voer het eerste getal in:");
            double number2 = 0;  // Default in case we don't need number2

            // Vraag alleen om het tweede getal als dat nodig is
            if (operation != "sqrt" && operation != "18+")
            {
                number2 = GetNumber("Voer het tweede getal in:");
            }

            switch (operation)
            {
                case "+":
                    Console.WriteLine($"Resultaat: {number1} + {number2} = {number1 + number2}");
                    break;
                case "-":
                    Console.WriteLine($"Resultaat: {number1} - {number2} = {number1 - number2}");
                    break;
                case "*":
                    Console.WriteLine($"Resultaat: {number1} * {number2} = {number1 * number2}");
                    break;
                case "/":
                    if (number2 != 0)
                        Console.WriteLine($"Resultaat: {number1} / {number2} = {number1 / number2}");
                    else
                        Console.WriteLine("Delen door nul is niet toegestaan.");
                    break;
                case "%":
                    Console.WriteLine($"Resultaat: {number1} % {number2} = {number1 % number2}");
                    break;
                case "^":
                    Console.WriteLine($"Resultaat: {number1} ^ {number2} = {Math.Pow(number1, number2)}");
                    break;
                case "sqrt":
                    Console.WriteLine($"Resultaat: √{number1} = {Math.Sqrt(number1)}");
                    break;
                case "18+":
                    Console.WriteLine("Voer het jaartal in:");
                    int year = GetYear();
                    Console.WriteLine(CalculateAge(year));
                    break;
                default:
                    Console.WriteLine("Ongeldige operatie.");
                    break;
            }

            Console.WriteLine("Wilt u doorgaan? (ja/nee)");
            continueCalculating = Console.ReadLine().Trim().ToLower() == "ja";
        }
    }
    // Code Smell: Herhaalde logica in GetNumber en GetYear methodes.
    // Probleem: Zowel GetNumber als GetYear herhalen een soortgelijke logica voor invoer en validatie.
    // Mogelijk Probleem: Moet dezelfde validatie logica overal doorvoeren bij wijzigingen, wat de onderhoudbaarheid verlaagd.
    // Oplossing: Maak een algemene invoer- en validatiefunctie voor beide gevallen.
    // Refactoring Techniek: **Extract Method** - Maak een nieuwe, herbruikbare invoermethode voor validatie.

    // Code Smell: Magic strings zoals "sqrt", "18+" die herhaald worden.
    // Probleem: Het gebruik van magische strings maakt de code moeilijker uitbreidbaar en verhoogt de kans op typfouten.
    // Mogelijk Probleem: Als je meer bewerkingen toevoegt, moet je telkens deze magische waarden handmatig toevoegen en controleren.
    // Oplossing: Maak gebruik van een enum of constante waarden voor de bewerkingen.
    // Refactoring Techniek: **Replace Magic String with Constant** of **Introduce Enum** - Gebruik een enum voor de operatie-opties.


    static double GetNumber(string prompt)
    {
        double number;
        while (true)
        {
            Console.WriteLine(prompt);
            string input = Console.ReadLine();
            if (double.TryParse(input, out number))
                return number;

            Console.WriteLine("Ongeldige invoer, voer een geldig getal in.");
        }
    }

    static int GetYear()
    {
        int year;
        while (true)
        {
            string input = Console.ReadLine();
            if (int.TryParse(input, out year) && input.Length == 4)
                return year;

            Console.WriteLine("Ongeldige invoer, voer een geldig jaartal in (vier cijfers).");
        }
    }

    // Code Smell: Repetitive Complex Logic in CalculateAge.
    // Probleem: De leeftijdsberekening heeft meerdere voorwaarden en is moeilijk leesbaar.
    // Mogelijk Probleem: Moeilijk te begrijpen en uitbreiden.
    // Oplossing: Verdeel de leeftijdsberekening in kleinere methoden of verbeter de leesbaarheid door de voorwaarden op te splitsen.
    // Refactoring Techniek: **Extract Method** - Maak een aparte methode die de specifieke voorwaarden voor leeftijdsberekening behandelt.

    static string CalculateAge(int year)
    {
        DateOnly currentDate = DateOnly.FromDateTime(DateTime.Now);
        int age = currentDate.Year - year;

        if (age < 18 || (age == 18 && (currentDate.Month < 1 || (currentDate.Month == 1 && currentDate.Day < 1))))
        {
            return "Jonger dan 18!";
        }
        return "18+";
    }

    static void PrintGreeting()
    {
        Console.WriteLine("Welkom bij de Rekenmachine!");
    }
}






