﻿using System;
using System.Collections.Generic;

class MuziekAfspeellijst
{
    // De muziek afspeellijst als een List
    static List<string> afspeellijst = new List<string>
    {
        "Lady Gaga - Shallow", "Drake - Memories", "Shawn Mendes - Blinding Lights",
        "Maroon 5 - Memories", "Adele - Shallow", "Lady Gaga - Yellow",
        "The Weeknd - Leave the Door Open", "Imagine Dragons - Positions",
        "Adele - Positions", "The Weeknd - Someone Like You",
        "Adele - Positions", "Coldplay - Memories", "Dua Lipa - Good 4 U",
        "Billie Eilish - Blinding Lights", "Drake - Leave the Door Open"
    };

    static void Main()
    {
        while (true)
        {
            Console.WriteLine("\nHuidige afspeellijst:");
            ToonAfspeellijst();

            Console.WriteLine("\nOpties:");
            Console.WriteLine("1. Voeg een nummer toe");
            Console.WriteLine("2. Verplaats een nummer");
            Console.WriteLine("3. Verwijder een nummer");
            Console.WriteLine("4. Stop");
            Console.Write("Kies een optie: ");
            string keuze = Console.ReadLine();

            switch (keuze)
            {
                case "1":
                    VoegNummerToe();
                    break;
                case "2":
                    VerplaatsNummer();
                    break;
                case "3":
                    VerwijderNummer();
                    break;
                case "4":
                    return;  // Verlaat de applicatie
                default:
                    Console.WriteLine("Ongeldige keuze. Probeer het opnieuw.");
                    break;
            }
        }
    }

    // Methode om de huidige afspeellijst weer te geven
    static void ToonAfspeellijst()
    {
        for (int i = 0; i < afspeellijst.Count; i++)
        {
            Console.WriteLine($"{i + 1}. {afspeellijst[i]}");
        }
    }

    // Methode om een nummer toe te voegen
    static void VoegNummerToe()
    {
        Console.Write("Voer de titel van het nummer in (bijv. 'Artiest - Titel'): ");
        string nieuwNummer = Console.ReadLine();

        Console.Write("Op welke positie wil je het nummer toevoegen? (1 t/m {0}): ", afspeellijst.Count + 1);
        if (int.TryParse(Console.ReadLine(), out int positie) && positie >= 1 && positie <= afspeellijst.Count + 1)
        {
            afspeellijst.Insert(positie - 1, nieuwNummer);
            Console.WriteLine($"Nummer '{nieuwNummer}' toegevoegd op positie {positie}.");
        }
        else
        {
            Console.WriteLine("Ongeldige positie.");
        }
    }

    // Methode om een nummer te verplaatsen
    static void VerplaatsNummer()
    {
        Console.Write("Welk nummer wil je verplaatsen? (nummer van 1 t/m {0}): ", afspeellijst.Count);
        if (int.TryParse(Console.ReadLine(), out int vanPositie) && vanPositie >= 1 && vanPositie <= afspeellijst.Count)
        {
            string nummer = afspeellijst[vanPositie - 1];

            Console.Write("Naar welke positie wil je dit nummer verplaatsen? (1 t/m {0}): ", afspeellijst.Count);
            if (int.TryParse(Console.ReadLine(), out int naarPositie) && naarPositie >= 1 && naarPositie <= afspeellijst.Count)
            {
                // Verplaats het nummer
                afspeellijst.RemoveAt(vanPositie - 1);
                afspeellijst.Insert(naarPositie - 1, nummer);

                Console.WriteLine($"Nummer '{nummer}' verplaatst naar positie {naarPositie}.");
            }
            else
            {
                Console.WriteLine("Ongeldige positie.");
            }
        }
        else
        {
            Console.WriteLine("Ongeldige invoer.");
        }
    }

    // Methode om een nummer te verwijderen
    static void VerwijderNummer()
    {
        Console.Write("Welk nummer wil je verwijderen? (nummer van 1 t/m {0}): ", afspeellijst.Count);
        if (int.TryParse(Console.ReadLine(), out int positie) && positie >= 1 && positie <= afspeellijst.Count)
        {
            string verwijderdNummer = afspeellijst[positie - 1];
            afspeellijst.RemoveAt(positie - 1);
            Console.WriteLine($"Nummer '{verwijderdNummer}' is verwijderd.");
        }
        else
        {
            Console.WriteLine("Ongeldige invoer.");
        }
    }
}
