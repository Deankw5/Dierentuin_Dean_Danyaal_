﻿using System;

// Enum voor het type slot
public enum LockType
{
    None,
    Basic,
    Advanced
}

// Enum voor de kleur van de fiets
public enum Color
{
    Red,
    Blue,
    Green,
    Black,
    White
}

// Enum voor het type fiets
public enum BicycleType
{
    Standard,
    Electric
}

// De Bicycle klasse (Weekopdracht 18-1 en 18-2)
public class Bicycle
{
    // Eigenschappen van de fiets
    public LockType Lock { get; set; }
    public double FrameHeight { get; set; }
    public Color BicycleColor { get; set; }
    public BicycleType Type { get; set; }
    public double RangeInKm { get; set; }
    private bool isLocked;

    // Constructor voor de fiets
    public Bicycle(LockType lockType, double frameHeight, Color bicycleColor, BicycleType type, double rangeInKm)
    {
        Lock = lockType;
        FrameHeight = frameHeight;
        BicycleColor = bicycleColor;
        Type = type;
        RangeInKm = rangeInKm;
        isLocked = false;
    }

    // Methode om de fiets te vergrendelen
    public void LockBicycle()
    {
        isLocked = true;
    }

    // Methode om de fiets te ontgrendelen
    public void UnlockBicycle()
    {
        isLocked = false;
    }

    // Methode die de status van de fiets afdrukt
    public void Print()
    {
        Console.WriteLine($"Fiets details:");
        Console.WriteLine($"Kleur: {BicycleColor}");
        Console.WriteLine($"Framehoogte: {FrameHeight} cm");
        Console.WriteLine($"Slot type: {Lock}");
        Console.WriteLine($"Type: {Type}");
        Console.WriteLine($"Range: {RangeInKm} km / {KmToMiles(RangeInKm)} miles");
        Console.WriteLine($"Vergrendeld: {(isLocked ? "Ja" : "Nee")}");
        Console.WriteLine(); // Voor een lege regel tussen de fietsen
    }

    // Omrekeningen van km naar miles
    public double KmToMiles(double km)
    {
        return km * 0.621371192;
    }

    // Getters en Setters voor Range in miles
    public double RangeInMiles
    {
        get { return KmToMiles(RangeInKm); }
        set { RangeInKm = value / 0.621371192; }
    }
}

// Static Calculator Klasse (Weekopdracht 18-3)
public static class Calculator
{
    public static double Add(double a, double b)
    {
        return a + b;
    }

    public static double Sub(double a, double b)
    {
        return a - b;
    }
}

// Static Person Klasse (Weekopdracht 18-4)
public class Person
{
    private static int instanceCounter = 0;
    public string Name { get; set; }

    public Person(string name)
    {
        Name = name;
        instanceCounter++;
    }

    public static int InstanceCount()
    {
        return instanceCounter;
    }
}

// Static ConfigurationData Klasse (Weekopdracht 18-5)
public static class ConfigurationData
{
    public const string AppName = "My Bicycle App";
    public const string Version = "1.0.0";
    public const int MaxUsers = 1000;

    public static string GetAppName() => AppName;
    public static string GetVersion() => Version;
    public static int GetMaxUsers() => MaxUsers;
}

// Hoofdmethode om het programma uit te voeren
class Program
{
    static void Main(string[] args)
    {
        // Weekopdracht 18-1 en 18-2: Maak drie verschillende fietsen aan
        Bicycle bike1 = new Bicycle(LockType.Basic, 55.5, Color.Red, BicycleType.Standard, 50);
        Bicycle bike2 = new Bicycle(LockType.Advanced, 58.0, Color.Blue, BicycleType.Electric, 100);
        Bicycle bike3 = new Bicycle(LockType.None, 52.0, Color.Black, BicycleType.Standard, 0);

        // Vergrendel en ontgrendel de fietsen
        bike1.LockBicycle(); // Vergrendel bike1
        bike2.UnlockBicycle(); // Ontgrendel bike2

        // Print de details van elke fiets
        bike1.Print();
        bike2.Print();
        bike3.Print();

        // Weekopdracht 18-3: Calculator testen
        double sum = Calculator.Add(10, 5);
        double difference = Calculator.Sub(10, 5);
        Console.WriteLine($"Som: {sum}, Verschil: {difference}");

        // Weekopdracht 18-4: Person en instance counter
        Person person1 = new Person("John");
        Person person2 = new Person("Alice");
        Console.WriteLine($"Aantal gemaakte personen: {Person.InstanceCount()}");

        // Weekopdracht 18-5: Configuratie-instellingen
        Console.WriteLine($"App Naam: {ConfigurationData.GetAppName()}");
        Console.WriteLine($"Versie: {ConfigurationData.GetVersion()}");
        Console.WriteLine($"Max Aantal Gebruikers: {ConfigurationData.GetMaxUsers()}");
    }
}
