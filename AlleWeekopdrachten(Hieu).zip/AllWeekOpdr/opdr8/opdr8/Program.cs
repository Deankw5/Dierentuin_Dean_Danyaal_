﻿//OPDRACHT 8
using System;

class Program
{
    static void Main()
    {
        // Code Smell: Magic Number
        // Probleem: Het getal 3 wordt direct in de code gebruikt zonder uitleg waarom 3 specifiek is.
        // Mogelijke Nadeel: Het is moeilijk te begrijpen wat het getal 3 precies betekent in deze context.
        // Oplossing: Vervang het "magische" getal door een duidelijke constante die de betekenis verduidelijkt.
        // Refactoring Techniek: Replace Magic Number with Named Constant.

        // Loop van 1 tot en met 50
        for (int i = 1; i <= 50; i++)
        {
            // Code Smell: Gebruik van continue (Looping Overuse)
            // Probleem: Het gebruik van `continue` kan de leesbaarheid van de loop verminderen, vooral als er meerdere `continue`-uitspraken zijn.
            // Mogelijke Nadeel: Het kan verwarrend zijn om te begrijpen wat de loop precies doet.
            // Oplossing: Herstructureer de code zodat de `continue` niet nodig is.
            // Refactoring Techniek: Replace Continue with Conditional.

            // Als het getal deelbaar is door 3, sla het over
            if (i % 3 == 0)
            {
                continue;
            }

            // Print het getal als het niet deelbaar is door 3
            Console.WriteLine(i);
        }
    }
}